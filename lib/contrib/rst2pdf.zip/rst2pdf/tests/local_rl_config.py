''' Local reportlab configuration override.
    For testing, do not put the date in the PDF
'''

invariant = 1  # No date -- unchanging output
