# package
from test import regulartest, releasetest, sphinxtest
